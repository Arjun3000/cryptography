#include<iostream>
using namespace std;
int gcd(int a,int b)
{
	int t;
	while(b!=0)
	{
		t = b;
		b = a%b;
		a = t;
	}
	return t;
}
int extgcd(int a,int b,int &x,int &y)
{
	if(b==0)
	{
		x = 1;
		y = 0;
		return a;
	}
	int x1,y1;
	int xt = extgcd(b,a%b,x1,y1);
	x = y1;
	y = x1-(a/b)*y1;
	return xt;
}
int modinv(int a, int m)
    {
	    int x, y;
	    int g = extgcd(a, m, x, y);
	    return (x % m + m) % m;
	}
long long modexp(long long base,long long exp,long long mod)
{
	long long res = 1;
	base = base%mod;
	while(exp>0)
	{
		if(exp%2==1)
		{
			res = (res*base)%mod;
		}
		exp = exp/2;
		base = (base*base)%mod;
		
	}
	return res;
}

int main()
{
	int plain,p,q,n,phi,e,d,track;
	
	
	
	cout<<"plain text : ";
	cin>>plain;
	
	cout<<"enter p and q : ";
	cin>>p>>q;
	
	cout<<"enter e : ";
	cin>>e;
	
	n = p*q;
	phi = (p-1)*(q-1);
	
	while(e<phi)
	{
		track = gcd(e,phi);
		if(track==1)
		{
			break;
		}
		else
		{
			e++;
		}
	}
	
	d = modinv(e,phi);
	
	long long  enc,dec;
	
	enc = modexp(plain,d,n);
	dec = modexp(enc,e,n);
	
	if(plain==dec)
	{
		cout<<"verification done!";
	}
	else
	{
		cout<<"not verified!";
	}
}
