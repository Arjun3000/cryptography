//affine cipher
#include<iostream>
using namespace std;
int multi(int a,int b)
{
	int i;
	for(i=1;i<=100;i++)
	{
		if((a*i)%b==1)
		{
			return i;
		}
	}
}
int main()
{
	char plain[100],enc[100],dec[100];
	int k1,k2,i,l=0,numplain[100],numenc[100],numdec[100];
	
	cout<<"enter your plain text : ";
	cin.getline(plain,100);
	
	cout<<"enter your first key : ";
	cin>>k1;
	
	cout<<"enter your second key : ";
	cin>>k2;
	
	while(plain[l]!='\0')
	{
		l = l+1;
	}
    for(i=0;i<l;i++)
    {
    	plain[i] = toupper(plain[i]);
	}
	for(i=0;i<l;i++)
	{
		numplain[i] = plain[i]-'A';
	}
	for(i=0;i<l;i++)
	{
		numenc[i] = (k1*numplain[i]+k2)%26;
	}
	for(i=0;i<l;i++)
	{
		enc[i] = numenc[i]+'A';
	}
	cout<<"your encrypted text is : "<<enc;
	
	//decryption
	
	int k1_inv = multi(k1,26);
	
	for(i=0;i<l;i++)
	{
		numdec[i] = (k1_inv*(numenc[i]-k2+26))%26;
		dec[i] = numdec[i]+'A';
	}
	cout<<endl<<"decrypted text is : "<<dec;
	
}
