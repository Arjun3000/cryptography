#include<iostream>
#include<math.h>
using namespace std;
int prime(int a)
{
	int i;
	
	int count = 0;
	
	for(i=1;i<=a;i++)
	{
		if(a%i == 0)
		{
			count  = count + 1;
		}
	}
	if(count == 2)
	{
		return 1;
	}
	else
	{
		return -1;
	}
}
int main()
{
  int a,p;
  int t;
  cout<<"enter the value of a : ";
  cin>>a;
  cout<<"enter the value of p : ";
  cin>>p;
  
  int x = prime(p);
  
  if(a<=0 || a%p==0 || x == -1)
  {
  	cout<<"Not satiesfied";
  }
  else
  {
  	t = pow(a,p-1);
  	t = t%p;
  	cout<<"the solution of fermat little theorm is : "<<t;
  }
  

}
