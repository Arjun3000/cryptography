#include<iostream>
using namespace std;
int main()
{
	int plain[8];
	int i,j;
	cout<<"enter the bits : ";
	for(i=0;i<8;i++)
	{
		cin>>plain[i];
	}
	int rpt[4],lpt[4];
	
	for(i=0;i<4;i++)
	{
		lpt[i] = plain[i];
	}
	for(i=4,j=0;i<8;i++,j++)
	{
		rpt[j]=plain[i];
	}
	cout<<"left plain text is : "<<endl;
	for(i=0;i<4;i++)
	{
		cout<<lpt[i]<<"\t";
	}
	cout<<endl<<"right plain text is : "<<endl;
	for(i=0;i<4;i++)
	{
		cout<<rpt[i]<<"\t";
	}
	int key[4];
	cout<<endl<<"enter the key bits : "<<endl;
	for(i=0;i<4;i++)
	{
		cin>>key[i];
	}
	int nrpt[4];
	cout<<"executing exor function"<<endl;
	for(i=0;i<4;i++)
	{
		nrpt[i] = rpt[i]^key[i];
	}
	int cipher[8];
	for(i=0;i<4;i++)
	{
		cipher[i] = nrpt[i];
	}
	for(i=4,j=0;i<8;i++,j++)
	{
		cipher[i]=lpt[j];
	}
	cout<<"cipher text is : ";
	for(i=0;i<8;i++)
	{
	   	cout<<cipher[i]<<"\t";
	}
	
	// decryption
	
	int nlpt[4],dec[8];
	for(i=0;i<4;i++)
	{
		lpt[i]=cipher[i];
	}
	for(i=0;i<4;i++)
	{
		nlpt[i] = lpt[i]^key[i];
	}
	
    for(i=4,j=0;i<8;i++,j++)
	{
		dec[j]=cipher[i];
	}
	for(i=4,j=0;i<8;i++,j++)
	{
		dec[i] = nlpt[j];
	}	
	cout<<endl<<"original text is : "<<endl;
	for(i=0;i<8;i++)
	{
		cout<<dec[i]<<"\t";
	}

}
