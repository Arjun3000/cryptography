#include<iostream>
using namespace std;
int main()
{
	char arr[5][6] = {"MONAR","CHYBD","EFGIK","LPQST","UVWXZ"};
	char plain[3],cipher[3];
	cout<<"enter your plain text : ";
	cin.getline(plain,3);
	cout<<"the playfair matrix is : "<<endl;
	int i,j,r1=0,r2=0,c1=0,c2=0;
	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)
		{
			cout<<arr[i][j]<<"\t";
		}
		cout<<endl;
	}
	for(i=0;i<2;i++)
	{
		plain[i] = toupper(plain[i]);
	}
	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)
		{
			if(arr[i][j]==plain[0])
			{
				r1 = i;
				c1 = j;
			}
			if(arr[i][j]==plain[1])
			{
				r2 = i;
				c2 = j;
			}
		}
	}
	if(r1==r2)
	{
		cipher[0] = arr[r1][(c1+1)%5];
		cipher[1] = arr[r2][(c2+1)%5];
	}
		
	else if(c1==c2)
	{	
		cipher[0] = arr[(r1+1)%5][c1];
		cipher[1] = arr[(r2+1)%5][c2];	
	}
	else
	{
		cipher[0] = arr[r1][c2];
		cipher[1] = arr[r2][c1];
	}
	cipher[2] = '\0';
	cout<<endl<<"your cipher text is : "<<cipher;
	
	
	
	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)
		{
			if(arr[i][j] == cipher[0])
			{
				r1 = i;
				c1 = j;
			}
			if(arr[i][j] == cipher[1])
			{
				r2 = i;
				c2 = j;
			}
		}
	}
	if(r1 == r2)
	{
		plain[0] = arr[r1][(c1+4)%5];
		plain[1] = arr[r2][(c2+4)%5];
	}
	else if(c1==c2)
	{	
		plain[0] = arr[(r1+4)%5][c1];
		plain[1] = arr[(r2+4)%5][c2];	
	}
	else
	{
		plain[0] = arr[r1][c2];
		plain[1] = arr[r2][c1];
	}
	
	plain[2] ='\0';
	cout<<endl<<"original text was : "<<plain<<endl;
	return 0;
}
