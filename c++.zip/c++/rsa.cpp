//rsa algo
#include<iostream>
using namespace std;
int multi(int a,int b)
{
	int x;
	for(x=1;x<1000;x++)
	{
		if((a*x)%b==1)
		{
			return x;
		}
	}
}
int gcd(int a,int b)
{
	int t;
	while(b!=0)
	{
		t = b;
		b = a%b;
		a = t;
	}
	return a;	
}
long long modinv(long long base,long long exp,long long mod)
{
	long long res = 1;
	base = base%mod;
	while(exp>0)
	{
	
		if(exp%2==1)
		{
			res = (res*base)%mod;
		}
		exp = exp/2;
		base = (base*base)%mod;
    }  
	return res;
}
int main()
{
	
	int plain;
	cout<<"enter plain text : ";
	cin>>plain;
	
	int p,q;
	int n,phi,e,d;
	
	cout<<"enter two prime numbers p and q : ";
	cin>>p>>q;
	
	n = p*q;
	phi = (p-1)*(q-1);
	
	cout<<"enter value of e : ";
	cin>>e;
	int track;
	
	while(e<phi)
	{
		track = gcd(e,phi);
		if(track == 1)
		{
			break;
		}
		else
		{
			e++;
		}
	}
	
	d = multi(e,phi);
	
	cout<<"value of e is : "<<e<<endl;
	cout<<"value of d is : "<<d<<endl;
	
	
	int enc = modinv(plain,e,n);
	cout<<"encrypted text is : "<<enc<<endl;
    
	
	int dec = modinv(enc,d,n);
	cout<<"decrypted text is : "<<dec<<endl;
	
	return 0;	
}

